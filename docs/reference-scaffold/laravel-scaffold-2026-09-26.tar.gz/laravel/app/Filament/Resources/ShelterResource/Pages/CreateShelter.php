<?php

namespace App\Filament\Resources\ShelterResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use App\Filament\Resources\ShelterResource;

class CreateShelter extends CreateRecord
{
    protected static string $resource = ShelterResource::class;
}