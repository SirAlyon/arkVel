<?php

namespace App\Filament\Resources\ShelterResource\Pages;

use Filament\Resources\Pages\ListRecords;
use App\Filament\Resources\ShelterResource;

class ListShelters extends ListRecords
{
    protected static string $resource = ShelterResource::class;
}