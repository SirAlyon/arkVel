<?php

namespace App\Filament\Resources\ShelterResource\Pages;

use Filament\Resources\Pages\EditRecord;
use App\Filament\Resources\ShelterResource;

class EditShelter extends EditRecord
{
    protected static string $resource = ShelterResource::class;
}